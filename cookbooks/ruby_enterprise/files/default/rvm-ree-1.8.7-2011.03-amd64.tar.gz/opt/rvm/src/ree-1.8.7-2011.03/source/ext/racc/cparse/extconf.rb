# $Id$

require 'mkmf'
create_makefile 'racc/cparse'
