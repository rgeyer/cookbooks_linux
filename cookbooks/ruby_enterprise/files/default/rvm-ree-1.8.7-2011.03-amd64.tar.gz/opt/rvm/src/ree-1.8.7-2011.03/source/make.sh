#!/bin/bash
exec make PREINCFLAGS='-I/opt/local/include' PRELIBS='-L/opt/local/lib -Wl,-rpath,/opt/rvm/rubies/ree-1.8.7-2011.03/lib -L/opt/rvm/rubies/ree-1.8.7-2011.03/lib -ltcmalloc_minimal ' "$@"